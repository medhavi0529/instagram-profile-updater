package firstScript;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;

public class Instagram {

    // Configuration
    private static final String CHROME_DRIVER_PATH = "C:\\New\\Webdriver\\chromedriver-win64\\chromedriver.exe"; // Path to your ChromeDriver
    private static final String INSTAGRAM_USERNAME = "mindimegana"; // Your Instagram username
    private static final String INSTAGRAM_PASSWORD = "mithila@2001"; // Your Instagram password
    // IMPORTANT: Make sure this path is correct and the image file exists.
    // Use forward slashes or double backslashes for Windows paths.
    private static final String NEW_PROFILE_PICTURE_PATH = "C:\\Users\\ASUS\\eclipse-workspace\\firstScript\\src\\images\\Instagrame profile.jpg"; // Updated path
    private static final String NEW_BIO = " Building digital solutions " + java.time.LocalDate.now().getYear() + ".";
    private static final String NEW_GENDER_TEXT = "Female"; // Or "Male", "Custom", "Prefer not to say"

    private WebDriver driver;
    private WebDriverWait wait;

    public void setup() {
        System.out.println("Setting up WebDriver...");
        System.setProperty("webdriver.chrome.driver", CHROME_DRIVER_PATH);
        ChromeOptions options = new ChromeOptions();

        // Optimized Chrome options for faster execution and less interference
        options.addArguments(
                "--start-maximized", // Start browser maximized
                "--disable-gpu", // Disable GPU hardware acceleration
                "--no-sandbox", // Bypass OS security model (needed for some environments)
                "--disable-dev-shm-usage", // Overcome limited resource problems
                "disable-infobars", // Disable "Chrome is being controlled by automated test software" infobar
                "--disable-notifications", // Disable browser notifications
                "--disable-popup-blocking" // Disable popup blocking
        );
        // Exclude 'enable-automation' switch to prevent detection by some sites
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});

        driver = new ChromeDriver(options);
        // Reduced wait timeout for faster feedback and execution
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        System.out.println("WebDriver setup complete.");
    }
    public void login(String username, String password) {
        System.out.println("Navigating to Instagram and logging in...");
        driver.get("https://www.instagram.com/");

        // Try to handle the cookie consent dialog if it appears (short timeout)
        try {
            System.out.println("Checking for cookie consent dialog...");
            new WebDriverWait(driver, Duration.ofSeconds(5))
                    .until(ExpectedConditions.elementToBeClickable(
                            By.xpath("//button[contains(., 'Allow') or contains(., 'Accept')]")))
                    .click();
            System.out.println("Cookie consent dialog handled.");
        } catch (TimeoutException e) {
            System.out.println("No cookie consent dialog found or it timed out.");
            // No cookie dialog found, continue
        }
        // Optimized login sequence: wait for elements and then send keys and click
        System.out.println("Entering username and password...");
        WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
        WebElement passwordField = driver.findElement(By.name("password")); // Find password field
        WebElement loginButton = driver.findElement(By.xpath("//button[@type='submit']")); // Find login button
        // Send keys without clearing first (faster if fields are empty)
        usernameField.sendKeys(username);
        passwordField.sendKeys(password);
        loginButton.click();
        System.out.println("Login button clicked.");

        // Handle post-login popups (e.g., "Save Info", "Turn on Notifications")
        handlePostLoginPopups();

        // Verify successful login by checking for the presence of the home icon (or another reliable element)
        System.out.println("Verifying successful login...");
        wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//*[name()='svg' and @aria-label='Home']")));
        System.out.println("Login successful!");
    }

    private void handlePostLoginPopups() {
        // Combined popup handling with shorter timeout
        System.out.println("Checking for post-login popups...");
        try {
            new WebDriverWait(driver, Duration.ofSeconds(5)) // Short timeout for popups
                    .until(ExpectedConditions.elementToBeClickable(
                            By.xpath("//div[contains(., 'Not Now') or contains(., 'not now')]")))
                    .click();
            System.out.println("Post-login popup handled.");
        } catch (TimeoutException e) {
            System.out.println("No post-login popup found or it timed out.");
            // Popup not found, continue
        }
    }
    public void updateProfile(String bio, String gender, String imagePath) throws IOException, InterruptedException {
        System.out.println("Navigating to edit profile page...");
        // Navigate directly to edit profile to save time
        driver.get("https://www.instagram.com/accounts/edit/");
        wait.until(ExpectedConditions.urlContains("/accounts/edit/")); // Wait for URL to change to edit profile page
        System.out.println("On edit profile page.");

        // Update components in sequence.
        // It's crucial to ensure elements are ready before interacting.
        updateProfilePicture1(imagePath);
        updateBio(bio);
        updateGender(gender);

        submitChanges();
        System.out.println("Profile update process initiated.");
    }
    private void updateProfilePicture1(final String imagePath) throws InterruptedException {
        try {
            // Click Change Photo button with more reliable XPaths
            WebElement changePhotoButton = findElementFast(
                "//div[text()='Change profile photo']",
                "//div[@role='button' and contains(., 'Change photo')]",
                "//span[contains(text(), 'Change photo')]/.."
            );
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", changePhotoButton);
            
            // Wait for modal to appear
            Thread.sleep(2000);
            
            // Try different ways to upload photo
            try {
                // Method 1: Direct file input
                WebElement fileInput = driver.findElement(By.xpath("//input[@type='file']"));
                fileInput.sendKeys(imagePath);
            } catch (Exception e) {
                // Method 2: Click upload option first
                WebElement uploadOption = findElementFast(
                    "//button[contains(., 'Select from computer')]",
                    "//div[contains(text(), 'Upload photo')]"
                );
                uploadOption.click();
                WebElement fileInput = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//input[@type='file']")));
                fileInput.sendKeys(imagePath);
            }
        } catch (Exception e) {
            System.err.println("Profile picture update failed: " + e.getMessage());
        }
    }
    private void updateBio(String bio) {
        System.out.println("Attempting to update bio...");
        try {
            WebElement bioTextArea = findElementFast(
                    "//textarea[@aria-label='Bio']",
                    "//textarea[@data-testid='settings-form-bio-textarea']",
                    "//textarea[@placeholder='Bio']",
                    "//label[text()='Bio']/following-sibling::textarea"
            );
            bioTextArea.clear();
            bioTextArea.sendKeys(bio);
            System.out.println("Bio updated to: " + bio);
        } catch (Exception e) {
            System.err.println("Bio update failed: " + e.getMessage());
        }
    }
    private void updateGender(String gender) {
        System.out.println("Attempting to update gender...");

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            // Step 1: Click on the gender dropdown
            WebElement genderSection = findElementFast(
                    "//div[@role='button' and contains(., 'Prefer not to say')]",
                    "//div[@role='button' and @aria-expanded='false']",
                    "//label[text()='Gender']/following-sibling::div[@role='button']"
            );
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", genderSection);

            // Step 2: Wait for options to be visible (if using checkboxes or role=option)
            wait.until(ExpectedConditions.or(
                    ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@type='checkbox' and @name='checkbox']")),
                    ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@role='option']"))
            ));

            // Step 3: Try selecting the gender via checkbox (if present)
            try {
                WebElement checkbox = driver.findElement(By.xpath("//input[@type='checkbox' and @name='checkbox']"));
                boolean isChecked = checkbox.isSelected();
                System.out.println("Checkbox found. Checked: " + isChecked);

                if ((gender.equalsIgnoreCase("Female") && !isChecked) ||
                    (gender.equalsIgnoreCase("Prefer not to say") && isChecked)) {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkbox);
                    System.out.println("Checkbox toggled for gender: " + gender);
                    return;
                }
            } catch (NoSuchElementException e) {
                System.out.println("Checkbox not found. Trying standard gender option selection...");
            }

            // Step 4: Fallback to select gender via option menu
            List<String> genderXPaths = Arrays.asList(
            	    "//div[@role='dialog']//div[text()='" + gender + "']",
            	    "//div[@role='option' and text()='" + gender + "']",
            	    "//div[@role='menuitem' and text()='" + gender + "']",
            	    "//span[text()='" + gender + "']/ancestor::div[@role='option']"
            	);
            WebElement genderOption = null;
            for (String xpath : genderXPaths) {
                try {
                    genderOption = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
                    break;
                } catch (Exception ignored) {
                }
            }

            if (genderOption != null) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", genderOption);
                System.out.println("Gender updated to: " + gender);
            } else {
                throw new NoSuchElementException("Gender option '" + gender + "' not found.");
            }

        } catch (Exception e) {
            System.err.println("Gender update failed: " + e.getMessage());
            
        }
    }

    private void submitChanges() {
        System.out.println("Submitting profile changes...");
        try {
            WebElement submitButton = findElementFast(
                    "//button[text()='Submit']",
                    "//button[@type='submit' and text()='Submit']",
                    "//div[@role='button' and text()='Submit']"
            );

            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", submitButton);
            System.out.println("Submit button clicked.");

            // Wait a short time before navigating
            Thread.sleep(2000);

            // Manually go to profile page
            String profileUrl = "https://www.instagram.com/" + INSTAGRAM_USERNAME + "/";
            driver.get(profileUrl);

            // Confirm profile page has loaded
           

            System.out.println("Changes submitted and navigated to profile page: " + profileUrl);

        } catch (Exception e) {
            System.err.println("Submit failed: " + e.getMessage());
        }
    }

    // Helper method to find an element using multiple XPaths with a short timeout
    // This makes the script more resilient to minor UI changes by trying alternatives.
    private WebElement findElementFast(String... xpaths) {
        for (String xpath : xpaths) {
            try {
                // Try to locate the element with a short, specific wait
                return new WebDriverWait(driver, Duration.ofSeconds(5)) // Increased from 3s to 5s for better stability
                        .until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
            } catch (TimeoutException e) {
                // If not found with the current XPath, try the next one in the list
                continue;
            }
        }
        // If none of the XPaths find the element after trying all of them, throw an exception
        throw new NoSuchElementException("Element not found with any provided locator for xpaths: " + String.join(" | ", xpaths));
    }

    public void tearDown() {
        System.out.println("Tearing down WebDriver...");
        if (driver != null) {
            driver.quit(); // Close all browser windows and end the WebDriver session
        }
        System.out.println("WebDriver torn down.");
    }

    public static void main(String[] args) {
        Instagram automator = new Instagram();
        try {
            automator.setup();
            automator.login(INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD);
            automator.updateProfile(NEW_BIO, NEW_GENDER_TEXT, NEW_PROFILE_PICTURE_PATH);
            System.out.println("Instagram automation completed successfully!");
        } catch (FileNotFoundException e) {
            System.err.println("Error: The specified profile picture file was not found. " + e.getMessage());
        } catch (Exception e) {
            System.err.println("An unexpected error occurred during automation: " + e.getMessage());
            e.printStackTrace(); // Print stack trace for detailed error analysis
        } finally {
            automator.tearDown(); // Ensure the browser is closed even if an error occurs
        }
    }
}
