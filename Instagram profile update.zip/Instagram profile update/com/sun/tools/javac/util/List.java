package com.sun.tools.javac.util;

public record List() {

}
